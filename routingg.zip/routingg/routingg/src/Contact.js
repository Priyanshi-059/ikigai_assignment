const Contact = () => {
    return (
      <div className="container mt-5">
        <h2>Contact</h2>
        <p>This is the Contact page of the React Routing Example.</p>
        <p style={{fontSize: "300px"}}><b>Contact</b></p>
      </div>
    );
  };
  
  export default Contact;
  